import React, { useState, useEffect, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { AlertCircle, MessageSquare, ThumbsUp, ThumbsDown, Minus } from 'lucide-react';

const Dashboard = () => {
  const [data, setData] = useState([]);
  const [selectedEmotion, setSelectedEmotion] = useState(null);
  const [selectedDomain, setSelectedDomain] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("http://127.0.0.1:5000/get-data")
      .then((response) => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
      })
      .then((json) => {
        console.log("Fetched data:", json);
        setData(json);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        setError(error.message);
        setLoading(false);
      });
  }, []);

  const stats = useMemo(() => {
    const total = data.length;
    const complaints = data.filter(d => d['Complaint Label'] === '1').length;
    const nonComplaints = total - complaints;
    const positive = data.filter(d => d.Sentiment === 'Positive').length;
    const negative = data.filter(d => d.Sentiment === 'Negative').length;
    const neutral = data.filter(d => d.Sentiment === 'Neutral').length;

    return { total, complaints, nonComplaints, positive, negative, neutral };
  }, [data]);

  const emotionData = useMemo(() => {
    const emotions = {};
    data.forEach(item => {
      if (item.Emotion) {
        emotions[item.Emotion] = (emotions[item.Emotion] || 0) + 1;
      }
    });
    return Object.entries(emotions).map(([name, value]) => ({ name, value }));
  }, [data]);

  const domainCounts = useMemo(() => {
    const domains = {};
    data.forEach(item => {
      if (item.Domain) {
        domains[item.Domain] = (domains[item.Domain] || 0) + 1;
      }
    });
    return Object.entries(domains).sort((a, b) => b[1] - a[1]);
  }, [data]);

  const emotionColors = {
    happiness: '#10b981',
    anger: '#ef4444',
    frustration: '#f97316',
    sadness: '#6366f1',
    surprise: '#8b5cf6',
    disappointment: '#ec4899',
    anxiety: '#14b8a6',
    worry: '#f59e0b',
    fear: '#dc2626'
  };

  const COLORS = ['#3b82f6', '#8b5cf6', '#ef4444', '#f59e0b', '#10b981', '#ec4899', '#14b8a6', '#6366f1'];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <div className="text-xl">Loading data...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center text-white bg-red-900/20 border border-red-500 rounded-lg p-8">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <div className="text-xl mb-2">Error Loading Data</div>
          <div className="text-slate-400">{error}</div>
          <div className="text-sm text-slate-500 mt-4">Make sure the backend is running on http://127.0.0.1:5000</div>
        </div>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="text-xl">No data available</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white p-6"
>
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            Dashboard: Customer Feedback Analysis
          </h1>
          <p className="text-slate-400 mt-2">Analyzing {stats.total} customer reviews</p>
        </header>

        <section className="mb-12">
         <h1 className="text-4xl font-semibold mb-6 text-blue-300" style={{ fontFamily: 'Bricolage Grotesque, sans-serif' }}>Overview Stats</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-blue-200 to-blue-300 rounded-2xl p-6 shadow-xl transform hover:scale-105 transition-transform">
  <MessageSquare className="w-8 h-8 mb-3 opacity-80 text-blue-700" />
  <div className="text-2xl opacity-90 mb-1 text-blue-800">Total Reviews</div>
  <div className="text-4xl font-bold text-blue-900">{stats.total}</div>
</div>

            <div className="bg-gradient-to-br from-red-200 to-red-300 rounded-2xl p-6 shadow-xl transform hover:scale-105 transition-transform">
  <AlertCircle className="w-8 h-8 mb-3 opacity-80 text-red-700" />
  <div className="text-2xl opacity-90 mb-1 text-red-800">Complaints</div>
  <div className="text-4xl font-bold text-red-900">{stats.complaints}</div>
  <div className="w-full bg-red-400 h-2 rounded-full mt-3 overflow-hidden">
    <div 
      className="bg-red-700 h-full animate-pulse"
      style={{ width: `${(stats.complaints / stats.total) * 100}%` }}
    ></div>
  </div>
</div>

           <div className="bg-gradient-to-br from-green-200 to-green-300 rounded-2xl p-6 shadow-xl transform hover:scale-105 transition-transform">
  <ThumbsUp className="w-8 h-8 mb-3 font-bold text-green-900" />
  <div className="text-2xl font-bold text-green-900">Non-Complaints</div>
  <div className="text-4xl font-bold text-green-900">{stats.nonComplaints}</div>
  <div className="text-sm mt-2 opacity-80 text-green-800">Positive & Neutral Feedback</div>
</div>
          </div>
        </section>

        <section className="mb-12">
        <h1 className="text-4xl font-semibold mb-6 text-blue-300" style={{ fontFamily: 'Bricolage Grotesque, sans-serif' }}>Sentiment Analysis</h1>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-green-500/20 to-green-600/20 border border-green-500/30 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg">Positive 😊</span>
                <ThumbsUp className="w-6 h-6 text-green-400" />
              </div>
              <div className="text-4xl font-bold text-green-400 mb-3">{stats.positive}</div>
              <div className="w-full bg-slate-700 rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-green-500 h-full rounded-full transition-all duration-500"
                  style={{ width: stats.total > 0 ? `${(stats.positive / stats.total) * 100}%` : '0%' }}
                ></div>
              </div>
              <div className="text-sm text-slate-400 mt-2">
                {stats.total > 0 ? `${((stats.positive / stats.total) * 100).toFixed(1)}%` : '0%'}
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-500/20 to-slate-600/20 border border-blue-500/30 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg">Neutral 😐</span>
                <Minus className="w-6 h-6 text-blue-400" />
              </div>
              <div className="text-4xl font-bold text-blue-400 mb-3">{stats.neutral}</div>
              <div className="w-full bg-slate-700 rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-blue-500 h-full rounded-full transition-all duration-500"
                  style={{ width: stats.total > 0 ? `${(stats.neutral / stats.total) * 100}%` : '0%' }}
                ></div>
              </div>
              <div className="text-sm text-slate-400 mt-2">
                {stats.total > 0 ? `${((stats.neutral / stats.total) * 100).toFixed(1)}%` : '0%'}
              </div>
            </div>

            <div className="bg-gradient-to-br from-red-500/20 to-red-600/20 border border-red-500/30 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg">Negative 😞</span>
                <ThumbsDown className="w-6 h-6 text-red-400" />
              </div>
              <div className="text-4xl font-bold text-red-400 mb-3">{stats.negative}</div>
              <div className="w-full bg-slate-700 rounded-full h-3 overflow-hidden">
                <div 
                  className="bg-red-500 h-full rounded-full transition-all duration-500"
                  style={{ width: stats.total > 0 ? `${(stats.negative / stats.total) * 100}%` : '0%' }}
                ></div>
              </div>
              <div className="text-sm text-slate-400 mt-2">
                {stats.total > 0 ? `${((stats.negative / stats.total) * 100).toFixed(1)}%` : '0%'}
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
        <h1 className="text-4xl font-semibold mb-6 text-blue-300" style={{ fontFamily: 'Bricolage Grotesque, sans-serif' }}>Complaint Domain</h1>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {domainCounts.map(([domain, count], idx) => (
              <div key={domain} className="space-y-2">
                <div
                  onClick={() => setSelectedDomain(selectedDomain === domain ? null : domain)}
                  className={`bg-slate-800/50 border border-slate-700 rounded-xl p-4 hover:bg-slate-700/50 transition-all cursor-pointer ${
                    selectedDomain === domain ? 'ring-2 ring-blue-500' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center text-2xl">
                      {['💳','🏦','🏧','💻','📞','💰','📊','💵','📱','↩️','🔄','🌐','📋'][idx % 13]}
                    </div>
                    <div className="flex-1">
                      <div className="text-xs text-slate-400 mb-1 line-clamp-2">{domain}</div>
                      <div className="text-lg font-bold">{count}</div>
                    </div>
                  </div>
                </div>

                {selectedDomain === domain && (
                  <div className="bg-slate-800/30 border border-slate-700 rounded-lg p-3 max-h-64 overflow-y-auto space-y-2">
                    {data
                      .filter(item => item.Domain === domain)
                      .map((item, i) => (
                        <div key={i} className="bg-slate-700/40 p-3 rounded-md">
                          <div className="text-sm text-blue-400 font-semibold mb-1 line-clamp-2">
                            {item['Domain Complaint/Opinion']}
                          </div>
                          <div className="text-xs text-slate-400">
                            Sentiment: {item.Sentiment} | Emotion: {item.Emotion}
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {emotionData.length > 0 && (
          <section className="mb-12">
        <h1 className="text-4xl font-semibold mb-6 text-blue-300" style={{ fontFamily: 'Bricolage Grotesque, sans-serif' }}>Emotion Analysis</h1>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                <h3 className="text-xl font-semibold mb-4">Emotion Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={emotionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {emotionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1e293b', 
                        border: '1px solid #475569',
                        borderRadius: '8px'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
                <h3 className="text-xl font-semibold mb-4">Filter by Emotion</h3>
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {emotionData.map((emotion) => (
                    <button
                      key={emotion.name}
                      onClick={() => setSelectedEmotion(emotion.name === selectedEmotion ? null : emotion.name)}
                      className={`w-full flex items-center justify-between p-3 rounded-lg transition-all ${
                        selectedEmotion === emotion.name 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-slate-700/50 hover:bg-slate-700 text-slate-300'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: emotionColors[emotion.name.toLowerCase()] || '#6366f1' }}
                        ></span>
                        {emotion.name}
                      </span>
                      <span className="font-semibold">{emotion.value}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {selectedEmotion && (
          <section className="mb-12">
            <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
              <h3 className="text-xl font-semibold mb-4">
                Feedback with emotion: {selectedEmotion}
              </h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {data
                  .filter(item => item.Emotion === selectedEmotion)
                  .map((item, idx) => (
                    <div key={idx} className="bg-slate-700/30 rounded-lg p-4 border border-slate-600">
                      <div className="flex items-start justify-between mb-2">
                        <span className="text-sm font-semibold text-blue-400">{item.Domain}</span>
                        <span className={`text-xs px-2 py-1 rounded ${
                          item['Complaint Label'] === '1' 
                            ? 'bg-red-500/20 text-red-400' 
                            : 'bg-green-500/20 text-green-400'
                        }`}>
                          {item['Complaint Label'] === '1' ? 'Complaint' : 'Non-Complaint'}
                        </span>
                      </div>
                      <p className="text-sm text-slate-300">{item['Domain Complaint/Opinion']}</p>
                      <div className="mt-2 text-xs text-slate-400">
                        Sentiment: {item.Sentiment}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </section>
        )}

        <footer className="text-center text-slate-500 text-sm mt-12 py-6 border-t border-slate-700">
          © 2025 Mittal Agencies  Analytics Limited. All Rights Reserved.
        </footer>
      </div>
    </div>
  );
};

export default Dashboard;